# A2C main
# coded by St.Watermelon

## 에이전트를 학습하고 결과를 도시하는 파일
# 필요한 패키지 임포트
from robust_q_learn import RobustQAgent
import numpy as np
import matplotlib.pyplot as plt
import gym

def main():
    train_num = 5
    max_episode_num = 1000   # 최대 에피소드 설정
    env_name = 'FrozenLake-v1'

    total_time = []
    total_reward = []

    for _ in range(train_num):
        env = gym.make(env_name)  # 환경으로 OpenAI Gym의 pendulum-v0 설정
        agent = RobustQAgent(env, max_episode_num)   # A2C 에이전트 객체

    # 학습 진행
        agent.train()
        time, reward = agent.get_average_result(10)
        total_time.append(time)
        total_reward.append(reward)

    print(total_reward)
    total_reward = np.mean(total_reward, axis = 0)

    plt.plot(total_reward)
    plt.show()

    # 학습 결과 도시
    # agent.plot_result()

if __name__=="__main__":
    main()
