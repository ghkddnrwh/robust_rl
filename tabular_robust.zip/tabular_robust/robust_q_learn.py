from threading import currentThread
from turtle import update
import tensorflow as tf

import numpy as np
import matplotlib.pyplot as plt
import math
import random

from tabular_robust.replaybuffer import ReplayBuffer

EPS_START = 1
EPS_END = 0.001


class TabularQ(object):
    def __init__(self, state_kind, action_kind):
        self.state_kind = state_kind
        self.action_kind = action_kind
        self.q_table = np.zeros((state_kind, action_kind), dtype = np.float32)
        # self.q_table = np.random.randn(state_kind, action_kind)
        self.v_table = np.zeros((state_kind), dtype = np.float32)

    # state, action에 대한 Q-Value 값 리턴
    def __call__(self, state, action):
        if state < 0 or state >= self.state_kind:
            print("Wrong state position")
            return 0
        if action < 0 or action >= self.action_kind:
            print("Wrong action position")
            return 0
            
        return self.q_table[state, action]

    # state에서 모든 action에 대한 Q-value 값을 벡터로 리턴
    def get_state_values(self, state):
        if state < 0 or state >= self.state_kind:
            print("Wrong state position")
            return 0

        return self.q_table[state]

    # Q-value, V-value 업데이트 이때 Greedy policy를 가정하기 때문에 V-value는 max로 업데이트
    # 여기서 V-value 업데이트 한는 값을 behavior policy로 해야되나 아니면 Greedy로 해야 되나?
    def update_q_value(self, state, action, update_value):
        if state < 0 or state >= self.state_kind:
            print("Wrong state position")
            return 0
        if action < 0 or action >= self.action_kind:
            print("Wrong action position")
            return 0
        self.q_table[state, action] = update_value
        self.v_table[state] = max(self.v_table[state], update_value)

    def get_v_value(self):
        return self.v_table

    def print(self):
        print("--------------------")
        for i in range(self.state_kind):
            print(self.q_table[i])
        print("--------------------")


class RobustQAgent(object):
    def __init__(self, env, max_episode_num):
        self.GAMMA = 0.95
        self.BATCH_SIZE = 64
        self.BUFFER_SIZE = 20000
        self.ALPHA = 0.01                   # Update 비율 / 여기서는 신경망을 사용 안하기 때문에 learning rate 대신 존재
        self.R = 0.1                        # robustness 의 정도 / 클수록 robustness 증가
        self.LEARNING_AFTER_STEP = 1000
        self.PTM_STEP = 10000               # PTM 업데이트 스텝
        self.MAX_EPISODE_NUM = max_episode_num

        self.env = env
        self.state_kind = env.observation_space.n
        self.action_kind = env.action_space.n

        self.robust_q = TabularQ(self.state_kind, self.action_kind)
        self.buffer = ReplayBuffer(self.BUFFER_SIZE)
        self.PTM = np.zeros((self.state_kind, self.state_kind))     # state to state transition의 가능성을 판단하는 행렬

        self.save_epi_time = []
        self.save_epi_reward = []

    # epsilon = 0 => greedy
    # epsilon = 1 => random
    def get_action(self, state, epsilon):
        p = np.random.rand()
        if p < epsilon:
            return np.random.randint(0, self.action_kind, size = 1)[0]
            
        state_value = self.robust_q.get_state_values(state)
        max_index = np.argwhere(state_value == np.amax(state_value))
        max_index = max_index.flatten().tolist()
        if len(max_index) == 1:
            return max_index[0]
        else:
            random.shuffle(max_index)
            return max_index[0]

    def q_learn(self, states, actions, q_targets):
        for i in range(states.shape[0]):
            state = states[i]
            action = actions[i]
            q_target = q_targets[i]

            current_q_value = self.robust_q(state, action)
            update_value = (1 - self.ALPHA) * current_q_value + self.ALPHA * q_target
            self.robust_q.update_q_value(state, action, update_value)

    # 수정 필요
    def q_target(self, rewards, r_values, v_values, dones, R):
        y_k = np.asarray(v_values)
        for i in range(v_values.shape[0]): # number of batch
            if dones[i]:
                y_k[i] = rewards[i]
            else:
                y_k[i] = rewards[i] + self.GAMMA * (R * r_values[i] + (1 - R) * v_values[i])
        return y_k

    def cal_r_value(self, states):
        r_values = []
        v_value = self.robust_q.get_v_value()
        for state in states:
            r_value = 0
            update_yet = True
            ptv = self.PTM[state]
            for next_state, probability in enumerate(ptv):
                if probability == 0:
                    continue
                if update_yet:
                    update_yet = False
                    r_value = v_value[next_state]
                else:
                    r_value = min(r_value, v_value[next_state])
            r_values.append(r_value)

        return np.array(r_values)

    def cal_epsilon(self, episode_ratio):
        a = - 1 / math.log(EPS_END)
        return math.exp(-episode_ratio / a)

    def cal_v_value(self, states):
        v_table = self.robust_q.get_v_value()
        state_value = []
        for state in states:
            state_value.append(v_table[state])

        return np.array(state_value)

    ## 에이전트 학습
    def train(self):
        r = 0
        # 에피소드마다 다음을 반복
        for ep in range(int(self.MAX_EPISODE_NUM)):

            # 에피소드 초기화
            time, episode_reward, done, truncated = 0, 0, False, False
            # 환경 초기화 및 초기 상태 관측
            state, _ = self.env.reset()
            epsilon = self.cal_epsilon(ep / self.MAX_EPISODE_NUM)
            print("Epsilon : ", epsilon)

            if self.buffer.buffer_count() > self.PTM_STEP:
                r = self.R

            while not done and not truncated:
                action = self.get_action(state, epsilon)

                next_state, reward, done, truncated, _ = self.env.step(action)

                done = done or truncated
                self.PTM[state, next_state] = 1

                self.buffer.add_buffer(state, action, reward, next_state, done)

                # 리플레이 버퍼가 일정 부분 채워지면 학습 진행
                if self.buffer.buffer_count() > self.LEARNING_AFTER_STEP:

                    # 리플레이 버퍼에서 샘플 무작위 추출
                    states, actions, rewards, next_states, dones = self.buffer.sample_batch(self.BATCH_SIZE)

                    r_values = self.cal_r_value(states)
                    v_values = self.cal_v_value(next_states)

                    y_i = self.q_target(rewards, r_values, v_values, dones, r)

                    self.q_learn(states, actions, y_i)

                    # 타깃 신경망 업데이트

                # 다음 스텝 준비
                state = next_state
                episode_reward += reward
                time += 1

            # 에피소드마다 결과 보상값 출력
            print('Episode: ', ep+1, 'Time: ', time, 'Reward: ', episode_reward)

            self.save_epi_time.append(time)
            self.save_epi_reward.append(episode_reward)
            self.robust_q.print()

            # # 에피소드마다 신경망 파라미터를 파일에 저장
            # self.actor.save_weights("./save_weights/pendulum_actor_2q.h5")
            # self.critic_1.save_weights("./save_weights/pendulum_critic_12q.h5")
            # self.critic_2.save_weights("./save_weights/pendulum_critic_22q.h5")

        # # 학습이 끝난 후, 누적 보상값 저장
        # np.savetxt('./save_weights/pendulum_epi_reward_2q.txt', self.save_epi_reward)
        # print(self.save_epi_reward)

    def get_average_result(self, average_interval):
        len = int(self.MAX_EPISODE_NUM / average_interval)
        cumulative_time = np.sum(np.reshape(self.save_epi_time, (len, average_interval)), axis = 1)
        cumulative_time = np.cumsum(cumulative_time)

        average_reward = np.reshape(self.save_epi_reward, (len, average_interval))
        average_reward = np.mean(average_reward, axis = 1)

        return cumulative_time, average_reward

    ## 에피소드와 누적 보상값을 그려주는 함수
    def plot_result(self):
        cumulative_time = np.sum(np.reshape(self.save_epi_time, (200, 10)), axis = 1)
        cumulative_time = np.cumsum(cumulative_time)

        average_reward = np.reshape(self.save_epi_reward, (200,10))
        average_reward = np.mean(average_reward, axis = 1)
        print(average_reward)
        plt.subplot(2, 1, 1)
        plt.plot(self.save_epi_reward)
        plt.subplot(2, 1, 2)
        plt.plot(cumulative_time, average_reward)

        plt.show()
        return
